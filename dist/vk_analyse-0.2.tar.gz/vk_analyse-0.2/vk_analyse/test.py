from getInformation import Information

info = Information()

test = info.expressAnalyse(55886191,'12957e86c516e3e1ac96e08e9a234f3fd307b1de4ab55d51a21ca9820240014bbe4af13000e5e41b19656')